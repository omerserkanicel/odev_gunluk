from flask import Flask, render_template,request, redirect, send_from_directory

# Importing the database library

from flask_sqlalchemy import SQLAlchemy



app = Flask(__name__)

# Connecting SQLite

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///diary.db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Creating a DB

db = SQLAlchemy(app)

# Creating a DB table

 

#Assignment #1. Create a DB table

class Card(db.Model):

    # Creating the fields

    #id

    id = db.Column(db.Integer, primary_key=True)

    # Title

    title = db.Column(db.String(100), nullable=False)

    # Description

    subtitle = db.Column(db.String(300), nullable=False)

    # Text

    text = db.Column(db.Text, nullable=False)

 

    # Outputting the object and its id

    def __repr__(self):

        return f'<Card {self.id}>'

# İlk sayfa
@app.route('/')
def baslangic():
    return render_template('baslangic.html')
   

# Form sonuçları 
@app.route('/index', methods=['GET','POST'])
def index():
    if request.method == 'POST':
        # seçilen resmi almak
        
        selected_image = request.form.get('image-selector')
        
        
        # Görev #2. Metni almak
        textTop = request.form["textTop"]

        textBottom = request.form["textBottom"]  
        
         
        # Görev #3. Metnin konumunu almak
        

        # Görev #3. Metnin rengini almak
        

        return render_template('index.html', 
                               # Seçilen resmi görüntüleme
                               selected_image=selected_image, 
                               # Görev #2. Metni görüntüleme 
                               textTop=textTop,
                               textBottom=textBottom,
                               # Görev #3. Rengi görüntüleme
                                                         
                               # Görev #3. Metnin konumunu görüntüleme
                               
                               )
    else:
        # Varsayılan olarak ilk resmi görüntüleme
        return render_template('index.html', selected_image='logo1.svg')


@app.route('/static/img/<path:path>')
def serve_images(path):
    return send_from_directory('static/img', path)

@app.route('/günlük')

def günlük():

    # Displaying the DB objects

    # Assignment #2. Display the objects from the DB in günlük.html

    cards = Card.query.order_by(Card.id).all()

 

    return render_template('günlük.html', cards=cards)

 

# Running the page with the card

@app.route('/card/<int:id>')

def card(id):

    # Assignment #2. Display the right card by its id

    card = Card.query.get(id)

 

    return render_template('card.html', card=card)

 

# Running the page and creating the card

@app.route('/create')

def create():

    return render_template('create_card.html')

# The card form

@app.route('/form_create', methods=['GET','POST'])

def form_create():

    if request.method == 'POST':

        title =  request.form['title']

        subtitle =  request.form['subtitle']

        text =  request.form['text']

 

        # Creating the object to send to the DB

 

        # Assignment #2. Create a way to store data in the DB

        card = Card(title=title, subtitle=subtitle, text=text)

 

        db.session.add(card)

        db.session.commit()

        return redirect('/')

    else:

        return render_template('create_card.html')

 

 

if __name__ == "__main__":

    app.run(debug=True)